To help satisfy the $33.5M civil court judgement against him, O.J.
Simpon's possessions were seized and auctioned on the internet, raising a total of $430,000.
Included was his Heisman Trophy, sold at $230,000.
Two No. 32 football jerseys, a Football Hall of Fame certificate and two trophies were purchased for $16,000, then burned or smashed on the steps of the Los Angeles Courthouse as a protest against failure in the criminal justice system.
In June 2000, Simpson offered to take a lie detector test if someone puts up a $3M reward to catch his ex-wife's killer.
In April 1999, Simpson was given custody of his two children, 13-year-old Sydney and 10-year-old Justin who were in the custody of the Brown family during Simpson's year in jail.
In August 1999, Nicole's sister and her lawyer asked the state attorney general to investigate perjury charges against Simpson for his testimony that he never hit, struck or slapped Nicole.
In July 2000, Simpson made an Internet chat appearance aimed at convincing the public that he didn't kill his ex-wife and her friend.
He was also scheduled to appear on NBC's Today, ABC's "The View" and FOX's "The Edge," but ABC cancelled.
On the Internet newsgroup alt.fan.oj-simpson, 645 members continue a daily debate on the minutiae of his guilt or innocence.
In September 2000, Simpson lost a bid in court to stop the broadcast of "American Tragedy," a television miniseries by the author Lawrence Schiller and Robert Kardashian, his former defense lawyer.
