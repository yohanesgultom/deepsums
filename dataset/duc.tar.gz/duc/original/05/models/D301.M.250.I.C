The main types of international organized crime are drug trafficking and drug money laundering.
Major players in these activities are the Colombian Medellin and Cali cartels, which dominate the world cocaine trade.
Also involved are the Mexican Sinoloa cartels and, in the US, Los Angeles street gangs allied with Colombian cartels.
Former Panamanian leader, General Manuel Noriega, was convicted of drug trafficking, money laundering, and conspiring with the Medellin cartel.
Cuban military officers have been involved in smuggling drugs, and Fidel Castro has been accused of mediating on behalf of the Medellin cartel.
Other Central and South American countries involved in drug trafficking include Belize, Costa Rica, Guatemala, Honduras, Peru, and Bolivia.
Drugs also are smuggled into the US through the Bahamas.
In Western Europe, Italy's Sicilian Mafia, Cosa Nostra, and Camorra engage in drug trafficking and money laundering, in association with Colombian cartels.
Italian organized crime deals in arms trafficking, as well.
Russian crime syndicates in Eastern Europe work with the Italian Mafia and Colombian cartels to funnel drugs into the US.
In Africa, crime syndicates deal in ivory, rhino horn, diamonds, arms, and drugs.
Nigerian drug rings smuggle heroin and cannabis throughout the world.
Chinese Triads and Japanese Yakuza work with crime syndicates in other countries.
Other international organized crimes include cigarette smuggling between the US and Canada, illicit arms sales between Israel and Colombian cartels, heroin smuggling from Turkey and along the Afghan/Pakistan border, human smuggling of prostitutes in Italy and illegal Chinese immigrants in the US.
