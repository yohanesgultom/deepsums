Since 1907, 175 Los Angeles area police officers have been killed in the line of duty.
Of those, 88 were felled by suspects, 36 killed in car crashes, 31 in motorcycle collisions, six in helicopter accidents, and 14 in other incidents.
Recent deaths include seven officers killed during drug operations.
One officer and two DEA agents were killed in undercover drug operations.
Another officer was killed in a helicopter accident during a drug interdiction mission.
One officer was shot by suspected drug dealers; another was shot during a drug raid; and another was shot trying to arrest a narcotics suspect.
Other circumstances surrounding police deaths are varied.
One officer was gunned down in retaliation for his testimony in a trial.
Two police bomb experts were blown up as they tried to dismantle a bomb found in a defendant's garage.
One officer was shot in a confrontation with a man who rushed into a restaurant brandishing a pistol.
Three officers were killed by suspects who were either mentally ill or under the influence of drugs, two with their own weapons.
Three officers were killed during high-speed chases.
One was shot pursuing robbery suspects; another was shot pursuing suspects in a gang-related drive-by shooting.
One officer died of complications of a shooting which occurred five years earlier.
Five officers died in vehicle collisions.
Two died of heart attacks while on duty.
Statistics for other areas include 14 officers killed in drug operations nation-wide, and officers shot in San Diego, Arkansas, and Texas.
