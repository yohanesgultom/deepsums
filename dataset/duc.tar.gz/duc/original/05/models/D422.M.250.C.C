Stolen art is often recovered during attempts to sell it.
A 17th century oil painting, stolen from Buckingham Palace, was found when offered to an auction house.
A former employee was charged.
Two portraits, brought to Sotheby's for evaluation by a man who bought them at a market, were recovered using the Art Loss Register database.
No suspects were arrested.
Works are recovered in undercover stings, such as a Picasso, recovered in Brussels, and a Rubens, recovered in Miami.
Suspects were arrested in both cases.
El Greco and Goya pieces were recovered in Miami, and a retired Argentine police commissioner and his wife were arrested.
Police work resulted in the recovery of Italian Renaissance masterpieces, Munch's Madonna, and a Monet and other works taken from Paris.
Arrests were made in all cases.
Tips helped police recover 81 Andy Warhol lithographs, and millions of dollars of art, including works by Dali and Matisse.
Three Munch's were recovered with assistance from one of the thieves.
Arrests were made in all cases.
In the strange category, 20 Van Gogh's were found in an abandoned getaway car, eight Matisse's were recovered in a traffic stop, and a tiny Renoir was found in a museum washroom ventilation duct.
Five masterpieces, including a Renoir, were recovered when the thief confessed and was arrested.
One of three stolen Van Gogh's was found in a car trunk, along with a ransom demand for the other two, which were later recovered.
Two men were convicted of the theft.
